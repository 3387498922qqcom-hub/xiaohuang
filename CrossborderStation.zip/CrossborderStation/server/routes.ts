import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import express from "express";
import path from "path";
import bcrypt from "bcrypt";
import { z } from "zod";
import { updateProfileSchema, changePasswordSchema, insertFeedbackSchema } from "@shared/schema";

const SALT_ROUNDS = 10;

async function hashPassword(password: string): Promise<string> {
  return await bcrypt.hash(password, SALT_ROUNDS);
}

async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return await bcrypt.compare(password, hash);
}

const phoneSchema = z.string().regex(/^1[3-9]\d{9}$/, "无效的手机号码");
const otpSchema = z.string().regex(/^\d{6}$/, "验证码必须是6位数字");
const passwordSchema = z.string().min(6, "密码至少6位").max(20, "密码最多20位");

export async function registerRoutes(app: Express): Promise<Server> {
  // Serve static files from public directory
  const publicPath = path.resolve(import.meta.dirname, "../public");
  app.use(express.static(publicPath));

  app.post("/api/auth/request-otp", async (req, res) => {
    try {
      const { phone } = req.body;
      
      const validation = phoneSchema.safeParse(phone);
      if (!validation.success) {
        return res.status(400).json({ 
          success: false, 
          message: validation.error.errors[0].message 
        });
      }

      const result = await storage.generateOTP(phone);
      
      if (!result) {
        return res.status(429).json({ 
          success: false, 
          message: "请求过于频繁，请1小时后再试" 
        });
      }

      // 开发环境：在响应中包含验证码（生产环境应删除此字段）
      const isDevelopment = process.env.NODE_ENV === 'development';
      
      res.json({ 
        success: true, 
        message: "验证码已发送",
        expiresAt: result.expiresAt,
        ...(isDevelopment && { code: result.code }) // 仅开发环境
      });
    } catch (error) {
      console.error("Request OTP error:", error);
      res.status(500).json({ success: false, message: "服务器错误" });
    }
  });

  app.post("/api/auth/verify-otp", async (req, res) => {
    try {
      const { phone, code, deviceId } = req.body;
      
      const phoneValidation = phoneSchema.safeParse(phone);
      if (!phoneValidation.success) {
        return res.status(400).json({ success: false, message: "无效的手机号码" });
      }

      const codeValidation = otpSchema.safeParse(code);
      if (!codeValidation.success) {
        return res.status(400).json({ success: false, message: "验证码格式错误" });
      }

      const isValid = await storage.verifyOTP(phone, code);
      
      if (!isValid) {
        return res.status(400).json({ 
          success: false, 
          message: "验证码错误或已过期" 
        });
      }

      let user = await storage.getUserByPhone(phone);
      if (!user) {
        user = await storage.createUser(phone);
      }

      await storage.updateLastLogin(phone);

      if (deviceId) {
        await storage.addTrustedDevice(phone, deviceId);
      }

      res.json({ 
        success: true, 
        message: "登录成功",
        user: {
          id: user.id,
          phone: user.phone,
          points: user.points,
          isVIP: user.isVIP
        }
      });
    } catch (error) {
      console.error("Verify OTP error:", error);
      res.status(500).json({ success: false, message: "服务器错误" });
    }
  });

  app.post("/api/auth/register", async (req, res) => {
    try {
      const { phone, password, code } = req.body;
      
      const phoneValidation = phoneSchema.safeParse(phone);
      if (!phoneValidation.success) {
        return res.status(400).json({ success: false, message: "无效的手机号码" });
      }

      const passwordValidation = passwordSchema.safeParse(password);
      if (!passwordValidation.success) {
        return res.status(400).json({ 
          success: false, 
          message: passwordValidation.error.errors[0].message 
        });
      }

      // 验证码是必需的
      if (!code) {
        return res.status(400).json({ success: false, message: "请输入验证码" });
      }

      const codeValidation = otpSchema.safeParse(code);
      if (!codeValidation.success) {
        return res.status(400).json({ success: false, message: "验证码格式错误" });
      }

      const isValid = await storage.verifyOTP(phone, code);
      if (!isValid) {
        return res.status(400).json({ 
          success: false, 
          message: "验证码错误或已过期" 
        });
      }

      const existingUser = await storage.getUserByPhone(phone);
      if (existingUser) {
        return res.status(400).json({ 
          success: false, 
          message: "该手机号已注册" 
        });
      }

      const passwordHash = await hashPassword(password);
      const user = await storage.createUser(phone, passwordHash);

      res.json({ 
        success: true, 
        message: "注册成功",
        user: {
          id: user.id,
          phone: user.phone,
          points: user.points
        }
      });
    } catch (error) {
      console.error("Register error:", error);
      res.status(500).json({ success: false, message: "服务器错误" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { phone, password, deviceId, rememberMe } = req.body;
      
      const phoneValidation = phoneSchema.safeParse(phone);
      if (!phoneValidation.success) {
        return res.status(400).json({ success: false, message: "无效的手机号码" });
      }

      const user = await storage.getUserByPhone(phone);
      if (!user || !user.passwordHash) {
        return res.status(401).json({ 
          success: false, 
          message: "手机号或密码错误" 
        });
      }

      if (!(await verifyPassword(password, user.passwordHash))) {
        return res.status(401).json({ 
          success: false, 
          message: "手机号或密码错误" 
        });
      }

      await storage.updateLastLogin(phone);

      if (rememberMe && deviceId) {
        await storage.addTrustedDevice(phone, deviceId);
      }

      res.json({ 
        success: true, 
        message: "登录成功",
        user: {
          id: user.id,
          phone: user.phone,
          points: user.points,
          isVIP: user.isVIP
        }
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ success: false, message: "服务器错误" });
    }
  });

  app.post("/api/auth/quick-login", async (req, res) => {
    try {
      const { phone, deviceId } = req.body;
      
      const phoneValidation = phoneSchema.safeParse(phone);
      if (!phoneValidation.success) {
        return res.status(400).json({ success: false, message: "无效的手机号码" });
      }

      if (!deviceId) {
        return res.status(400).json({ success: false, message: "缺少设备信息" });
      }

      const isTrusted = await storage.isTrustedDevice(phone, deviceId);
      if (!isTrusted) {
        return res.status(401).json({ 
          success: false, 
          message: "设备未授权，请使用完整登录" 
        });
      }

      const user = await storage.getUserByPhone(phone);
      if (!user) {
        return res.status(404).json({ success: false, message: "用户不存在" });
      }

      await storage.updateLastLogin(phone);

      res.json({ 
        success: true, 
        message: "快速登录成功",
        user: {
          id: user.id,
          phone: user.phone,
          points: user.points,
          isVIP: user.isVIP
        }
      });
    } catch (error) {
      console.error("Quick login error:", error);
      res.status(500).json({ success: false, message: "服务器错误" });
    }
  });

  app.post("/api/auth/reset-password", async (req, res) => {
    try {
      const { phone, code, newPassword } = req.body;
      
      const phoneValidation = phoneSchema.safeParse(phone);
      if (!phoneValidation.success) {
        return res.status(400).json({ success: false, message: "无效的手机号码" });
      }

      const passwordValidation = passwordSchema.safeParse(newPassword);
      if (!passwordValidation.success) {
        return res.status(400).json({ 
          success: false, 
          message: passwordValidation.error.errors[0].message 
        });
      }

      const isValid = await storage.verifyOTP(phone, code);
      if (!isValid) {
        return res.status(400).json({ 
          success: false, 
          message: "验证码错误或已过期" 
        });
      }

      const passwordHash = await hashPassword(newPassword);
      const success = await storage.updatePassword(phone, passwordHash);
      
      if (!success) {
        return res.status(404).json({ success: false, message: "用户不存在" });
      }

      res.json({ success: true, message: "密码重置成功" });
    } catch (error) {
      console.error("Reset password error:", error);
      res.status(500).json({ success: false, message: "服务器错误" });
    }
  });

  // User Profile Routes
  app.get("/api/user/profile", async (req, res) => {
    try {
      const { userId, phone } = req.body;
      
      if (!userId || !phone) {
        return res.status(401).json({ success: false, message: "未授权访问" });
      }
      
      const user = await storage.getUser(userId);
      
      if (!user || user.phone !== phone) {
        return res.status(403).json({ success: false, message: "无权访问此资源" });
      }

      res.json({ 
        success: true, 
        user: {
          id: user.id,
          phone: user.phone,
          username: user.username,
          avatar: user.avatar,
          realName: user.realName,
          bio: user.bio,
          points: user.points,
          isVIP: user.isVIP
        }
      });
    } catch (error) {
      console.error("Get profile error:", error);
      res.status(500).json({ success: false, message: "服务器错误" });
    }
  });

  app.put("/api/user/profile", async (req, res) => {
    try {
      const { userId, phone, ...profileData } = req.body;
      
      if (!userId || !phone) {
        return res.status(401).json({ success: false, message: "未授权访问" });
      }
      
      const user = await storage.getUser(userId);
      if (!user || user.phone !== phone) {
        return res.status(403).json({ success: false, message: "无权修改此资源" });
      }
      
      const validation = updateProfileSchema.safeParse(profileData);
      
      if (!validation.success) {
        return res.status(400).json({ 
          success: false, 
          message: validation.error.errors[0].message 
        });
      }

      // Avatar size limit: 500KB base64
      if (validation.data.avatar && validation.data.avatar.length > 700000) {
        return res.status(400).json({ 
          success: false, 
          message: "头像文件过大，请选择小于500KB的图片" 
        });
      }

      const success = await storage.updateProfile(userId, validation.data);
      
      if (!success) {
        return res.status(404).json({ success: false, message: "用户不存在" });
      }

      res.json({ success: true, message: "个人信息更新成功" });
    } catch (error) {
      console.error("Update profile error:", error);
      res.status(500).json({ success: false, message: "服务器错误" });
    }
  });

  app.put("/api/user/password", async (req, res) => {
    try {
      const { userId, phone, currentPassword, newPassword } = req.body;
      
      if (!userId || !phone) {
        return res.status(401).json({ success: false, message: "未授权访问" });
      }
      
      const user = await storage.getUser(userId);
      if (!user || user.phone !== phone) {
        return res.status(403).json({ success: false, message: "无权修改此资源" });
      }
      
      const validation = changePasswordSchema.safeParse({ currentPassword, newPassword });
      
      if (!validation.success) {
        return res.status(400).json({ 
          success: false, 
          message: validation.error.errors[0].message 
        });
      }

      if (!user.passwordHash) {
        return res.status(404).json({ success: false, message: "用户未设置密码" });
      }

      const isCurrentPasswordValid = await verifyPassword(
        validation.data.currentPassword, 
        user.passwordHash
      );
      
      if (!isCurrentPasswordValid) {
        return res.status(400).json({ success: false, message: "当前密码错误" });
      }

      if (validation.data.currentPassword === validation.data.newPassword) {
        return res.status(400).json({ success: false, message: "新密码不能与当前密码相同" });
      }

      const newPasswordHash = await hashPassword(validation.data.newPassword);
      const success = await storage.updatePassword(user.phone, newPasswordHash);
      
      if (!success) {
        return res.status(500).json({ success: false, message: "密码更新失败" });
      }

      res.json({ success: true, message: "密码修改成功" });
    } catch (error) {
      console.error("Change password error:", error);
      res.status(500).json({ success: false, message: "服务器错误" });
    }
  });

  // User Settings Routes
  app.get("/api/user/settings", async (req, res) => {
    try {
      const { userId, phone } = req.body;
      
      if (!userId || !phone) {
        return res.status(401).json({ success: false, message: "未授权访问" });
      }
      
      const user = await storage.getUser(userId);
      if (!user || user.phone !== phone) {
        return res.status(403).json({ success: false, message: "无权访问此资源" });
      }
      
      const settings = await storage.getUserSettings(userId);
      
      if (!settings) {
        return res.status(404).json({ success: false, message: "设置不存在" });
      }

      res.json({ success: true, settings });
    } catch (error) {
      console.error("Get settings error:", error);
      res.status(500).json({ success: false, message: "服务器错误" });
    }
  });

  app.put("/api/user/settings", async (req, res) => {
    try {
      const { userId, phone, messageNotify, checkinNotify, activityNotify, darkMode, themeColor, fontSize, language, privacyLevel } = req.body;
      
      if (!userId || !phone) {
        return res.status(401).json({ success: false, message: "未授权访问" });
      }
      
      const user = await storage.getUser(userId);
      if (!user || user.phone !== phone) {
        return res.status(403).json({ success: false, message: "无权修改此资源" });
      }
      
      const updates: any = {};
      if (messageNotify !== undefined) updates.messageNotify = messageNotify;
      if (checkinNotify !== undefined) updates.checkinNotify = checkinNotify;
      if (activityNotify !== undefined) updates.activityNotify = activityNotify;
      if (darkMode !== undefined) updates.darkMode = darkMode;
      if (themeColor !== undefined) updates.themeColor = themeColor;
      if (fontSize !== undefined) updates.fontSize = fontSize;
      if (language !== undefined) updates.language = language;
      if (privacyLevel !== undefined) updates.privacyLevel = privacyLevel;

      const success = await storage.updateUserSettings(userId, updates);
      
      if (!success) {
        return res.status(500).json({ success: false, message: "设置更新失败" });
      }

      res.json({ success: true, message: "设置已保存" });
    } catch (error) {
      console.error("Update settings error:", error);
      res.status(500).json({ success: false, message: "服务器错误" });
    }
  });

  // Feedback Route
  app.post("/api/feedback", async (req, res) => {
    try {
      const validation = insertFeedbackSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ 
          success: false, 
          message: validation.error.errors[0].message 
        });
      }

      const feedback = await storage.createFeedback(validation.data);
      
      res.json({ success: true, message: "感谢您的反馈！", feedback });
    } catch (error) {
      console.error("Submit feedback error:", error);
      res.status(500).json({ success: false, message: "服务器错误" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
