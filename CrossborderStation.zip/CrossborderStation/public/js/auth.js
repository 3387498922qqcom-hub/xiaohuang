// 跨界驿站 - 认证模块
// 集成：密码登录、OTP登录、注册、记住我、密码重置

class AuthManager {
    constructor() {
        this.apiBase = '/api/auth';
        this.deviceId = this.getDeviceId();
        this.countdown = null;
    }

    // 生成或获取设备指纹
    getDeviceId() {
        let deviceId = localStorage.getItem('deviceId');
        if (!deviceId) {
            deviceId = 'device_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
            localStorage.setItem('deviceId', deviceId);
        }
        return deviceId;
    }

    // 记住上次登录的手机号
    saveLastPhone(phone) {
        localStorage.setItem('lastPhone', phone);
    }

    getLastPhone() {
        return localStorage.getItem('lastPhone') || '';
    }

    // 显示加载状态
    showLoading(button, text = '处理中...') {
        button.disabled = true;
        button.dataset.originalText = button.textContent;
        button.textContent = text;
        button.classList.add('loading');
    }

    hideLoading(button) {
        button.disabled = false;
        button.textContent = button.dataset.originalText || button.textContent;
        button.classList.remove('loading');
    }

    // 显示错误消息
    showError(message) {
        // 创建toast提示
        const toast = document.createElement('div');
        toast.className = 'auth-toast error';
        toast.textContent = message;
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.classList.add('show');
        }, 10);
        
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    // 显示成功消息
    showSuccess(message) {
        const toast = document.createElement('div');
        toast.className = 'auth-toast success';
        toast.textContent = message;
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.classList.add('show');
        }, 10);
        
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    // 验证手机号格式
    validatePhone(phone) {
        return /^1[3-9]\d{9}$/.test(phone);
    }

    // 验证密码强度
    validatePassword(password) {
        if (password.length < 6) {
            return { valid: false, message: '密码至少6位', strength: 'weak' };
        }
        if (password.length > 20) {
            return { valid: false, message: '密码最多20位', strength: 'weak' };
        }

        let strength = 'weak';
        let score = 0;
        
        if (password.length >= 8) score++;
        if (/[a-z]/.test(password)) score++;
        if (/[A-Z]/.test(password)) score++;
        if (/\d/.test(password)) score++;
        if (/[^a-zA-Z\d]/.test(password)) score++;

        if (score >= 4) strength = 'strong';
        else if (score >= 2) strength = 'medium';

        return { valid: true, strength, score };
    }

    // 倒计时功能
    startCountdown(button, seconds = 60) {
        if (this.countdown) {
            clearInterval(this.countdown);
        }

        button.disabled = true;
        let count = seconds;
        button.textContent = `重新发送(${count}s)`;

        this.countdown = setInterval(() => {
            count--;
            button.textContent = `重新发送(${count}s)`;
            
            if (count <= 0) {
                clearInterval(this.countdown);
                this.countdown = null;
                button.disabled = false;
                button.textContent = '发送验证码';
            }
        }, 1000);
    }

    // API调用封装
    async apiCall(endpoint, data = {}) {
        try {
            const response = await fetch(this.apiBase + endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data),
            });

            const result = await response.json();
            
            if (!response.ok) {
                throw new Error(result.message || '请求失败');
            }

            return result;
        } catch (error) {
            throw new Error(error.message || '网络错误，请稍后重试');
        }
    }

    // 请求OTP验证码
    async requestOTP(phone) {
        if (!this.validatePhone(phone)) {
            throw new Error('请输入正确的手机号码');
        }

        const result = await this.apiCall('/request-otp', { phone });
        return result;
    }

    // 验证OTP并登录
    async verifyOTP(phone, code, rememberMe = false) {
        if (!this.validatePhone(phone)) {
            throw new Error('请输入正确的手机号码');
        }

        if (!/^\d{6}$/.test(code)) {
            throw new Error('验证码必须是6位数字');
        }

        const result = await this.apiCall('/verify-otp', {
            phone,
            code,
            deviceId: rememberMe ? this.deviceId : undefined
        });

        if (result.success && result.user) {
            this.saveUserSession(result.user);
            if (rememberMe) {
                this.saveLastPhone(phone);
            }
        }

        return result;
    }

    // 密码注册（带OTP验证）
    async register(phone, password, code) {
        if (!this.validatePhone(phone)) {
            throw new Error('请输入正确的手机号码');
        }

        const validation = this.validatePassword(password);
        if (!validation.valid) {
            throw new Error(validation.message);
        }

        // 验证码是必需的
        if (!code || !code.trim()) {
            throw new Error('请输入验证码');
        }

        if (!/^\d{6}$/.test(code)) {
            throw new Error('验证码必须是6位数字');
        }

        const result = await this.apiCall('/register', { phone, password, code });
        
        if (result.success && result.user) {
            // 注册成功，用户需要用密码登录
        }

        return result;
    }

    // 密码登录
    async login(phone, password, rememberMe = false) {
        if (!this.validatePhone(phone)) {
            throw new Error('请输入正确的手机号码');
        }

        if (!password) {
            throw new Error('请输入密码');
        }

        const result = await this.apiCall('/login', {
            phone,
            password,
            deviceId: rememberMe ? this.deviceId : undefined,
            rememberMe
        });

        if (result.success && result.user) {
            this.saveUserSession(result.user);
            if (rememberMe) {
                this.saveLastPhone(phone);
            }
        }

        return result;
    }

    // 快速登录（记住我）
    async quickLogin(phone) {
        const result = await this.apiCall('/quick-login', {
            phone,
            deviceId: this.deviceId
        });

        if (result.success && result.user) {
            this.saveUserSession(result.user);
        }

        return result;
    }

    // 重置密码
    async resetPassword(phone, code, newPassword) {
        if (!this.validatePhone(phone)) {
            throw new Error('请输入正确的手机号码');
        }

        if (!/^\d{6}$/.test(code)) {
            throw new Error('验证码必须是6位数字');
        }

        const validation = this.validatePassword(newPassword);
        if (!validation.valid) {
            throw new Error(validation.message);
        }

        const result = await this.apiCall('/reset-password', {
            phone,
            code,
            newPassword
        });

        return result;
    }

    // 保存用户会话
    saveUserSession(user) {
        const userData = {
            userId: user.id,
            username: user.username || `用户${user.phone.substring(7)}`,
            phone: user.phone,
            points: user.points || 0,
            isVIP: user.isVIP === 'true',
            vipExpiry: user.vipExpiry,
            loginTime: new Date().toISOString(),
            isLoggedIn: true,
        };

        if (window.SessionManager) {
            SessionManager.saveUserData(userData);
        }
    }

    // 跳转到指定页面
    navigateTo(url) {
        if (window.TransitionManager) {
            TransitionManager.navigateWithTransition(url);
        } else {
            window.location.href = url;
        }
    }
}

// 导出全局实例
window.AuthManager = new AuthManager();
