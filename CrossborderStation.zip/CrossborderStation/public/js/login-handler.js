// 登录页面交互逻辑
document.addEventListener('DOMContentLoaded', function() {
    const auth = window.AuthManager;
    
    // 获取DOM元素
    const loginTab = document.getElementById('loginTab');
    const registerTab = document.getElementById('registerTab');
    const mainBtn = document.getElementById('mainBtn');
    const phoneInput = document.getElementById('phone');
    const passwordInput = document.getElementById('password');
    const codeInput = document.getElementById('code');
    const registerPasswordInput = document.getElementById('registerPassword');
    const confirmPasswordInput = document.getElementById('confirmPassword');
    const rememberMeCheckbox = document.getElementById('rememberMe');
    const sendCodeBtn = document.getElementById('sendCode');
    const sendForgotCodeBtn = document.getElementById('sendForgotCode');
    const resetPasswordBtn = document.getElementById('resetPasswordBtn');
    
    // UI组
    const loginPasswordGroup = document.getElementById('loginPasswordGroup');
    const registerCodeGroup = document.getElementById('registerCodeGroup');
    const registerPasswordGroup = document.getElementById('registerPasswordGroup');
    const registerConfirmPasswordGroup = document.getElementById('registerConfirmPasswordGroup');
    const rememberMeGroup = document.getElementById('rememberMeGroup');
    const successMessage = document.getElementById('successMessage');
    const resetSuccessMessage = document.getElementById('resetSuccessMessage');
    
    // 密码强度指示器
    const passwordStrength = document.getElementById('passwordStrength');
    const passwordStrengthBar = document.getElementById('passwordStrengthBar');
    const passwordStrengthText = document.getElementById('passwordStrengthText');
    
    // 状态
    let isLogin = true;
    
    // 页面加载时填充上次登录的手机号
    const lastPhone = auth.getLastPhone();
    if (lastPhone && phoneInput) {
        phoneInput.value = lastPhone;
    }
    
    // 标签切换逻辑
    loginTab.addEventListener('click', () => {
        isLogin = true;
        loginTab.classList.add('active');
        registerTab.classList.remove('active');
        mainBtn.textContent = '登录';
        mainBtn.style.background = 'linear-gradient(135deg, #e6d3a3 0%, #d4b96a 100%)';
        
        // 显示/隐藏表单元素
        loginPasswordGroup.style.display = 'block';
        registerCodeGroup.style.display = 'none';
        registerPasswordGroup.style.display = 'none';
        registerConfirmPasswordGroup.style.display = 'none';
        rememberMeGroup.style.display = 'flex';
        successMessage.style.display = 'none';
        
        // 隐藏其他表单
        document.getElementById('emailForm').style.display = 'none';
        document.getElementById('forgotPasswordForm').style.display = 'none';
    });
    
    registerTab.addEventListener('click', () => {
        isLogin = false;
        registerTab.classList.add('active');
        loginTab.classList.remove('active');
        mainBtn.textContent = '注册并领取50积分';
        mainBtn.style.background = 'linear-gradient(135deg, #b89b5c 0%, #9c8148 100%)';
        
        // 显示/隐藏表单元素
        loginPasswordGroup.style.display = 'none';
        registerCodeGroup.style.display = 'block';
        registerPasswordGroup.style.display = 'block';
        registerConfirmPasswordGroup.style.display = 'block';
        rememberMeGroup.style.display = 'none';
        successMessage.style.display = 'none';
        
        // 隐藏其他表单
        document.getElementById('emailForm').style.display = 'none';
        document.getElementById('forgotPasswordForm').style.display = 'none';
    });
    
    // 密码强度实时检测
    if (registerPasswordInput) {
        registerPasswordInput.addEventListener('input', () => {
            const password = registerPasswordInput.value;
            
            if (password.length === 0) {
                passwordStrength.classList.remove('visible');
                passwordStrengthText.classList.remove('visible');
                return;
            }
            
            const validation = auth.validatePassword(password);
            passwordStrength.classList.add('visible');
            passwordStrengthText.classList.add('visible');
            
            // 重置所有class
            passwordStrengthBar.className = 'password-strength-bar';
            
            if (validation.valid) {
                passwordStrengthBar.classList.add(validation.strength);
                const strengthText = {
                    'weak': '弱',
                    'medium': '中等',
                    'strong': '强'
                };
                passwordStrengthText.textContent = `密码强度：${strengthText[validation.strength]}`;
            } else {
                passwordStrengthBar.classList.add('weak');
                passwordStrengthText.textContent = validation.message;
            }
        });
    }
    
    // 发送注册验证码
    sendCodeBtn.addEventListener('click', async () => {
        const phone = phoneInput.value.trim();
        
        try {
            auth.showLoading(sendCodeBtn, '发送中...');
            const result = await auth.requestOTP(phone);
            
            // 显示验证码到页面（仅开发环境，生产环境应发送短信）
            if (result.code) {
                auth.showSuccess(`验证码: ${result.code} (有效期5分钟)`);
            } else {
                auth.showSuccess('验证码已发送到您的手机');
            }
            
            auth.startCountdown(sendCodeBtn);
        } catch (error) {
            auth.showError(error.message);
        } finally {
            auth.hideLoading(sendCodeBtn);
        }
    });
    
    // 发送忘记密码验证码
    sendForgotCodeBtn.addEventListener('click', async () => {
        const phone = document.getElementById('forgotPhone').value.trim();
        
        try {
            auth.showLoading(sendForgotCodeBtn, '发送中...');
            const result = await auth.requestOTP(phone);
            
            // 显示验证码到页面（仅开发环境）
            if (result.code) {
                auth.showSuccess(`验证码: ${result.code} (有效期5分钟)`);
            } else {
                auth.showSuccess('验证码已发送到您的手机');
            }
            
            auth.startCountdown(sendForgotCodeBtn);
        } catch (error) {
            auth.showError(error.message);
        } finally {
            auth.hideLoading(sendForgotCodeBtn);
        }
    });
    
    // 主登录/注册按钮
    mainBtn.addEventListener('click', async () => {
        const phone = phoneInput.value.trim();
        const rememberMe = rememberMeCheckbox.checked;
        
        try {
            auth.showLoading(mainBtn);
            
            if (isLogin) {
                // 登录逻辑
                const password = passwordInput.value;
                await auth.login(phone, password, rememberMe);
                auth.showSuccess('登录成功！');
                
                // 跳转到个人中心
                setTimeout(() => {
                    auth.navigateTo('/pages/profile.html');
                }, 1000);
                
            } else {
                // 注册逻辑
                const code = codeInput.value.trim();
                const password = registerPasswordInput.value;
                const confirmPassword = confirmPasswordInput.value;
                
                // 验证码必填
                if (!code) {
                    throw new Error('请输入验证码');
                }
                
                if (password !== confirmPassword) {
                    throw new Error('两次输入的密码不一致');
                }
                
                // 直接调用register，内部会验证OTP并创建用户
                await auth.register(phone, password, code);
                
                auth.showSuccess('注册成功！请使用密码登录');
                
                // 清空表单
                phoneInput.value = '';
                codeInput.value = '';
                registerPasswordInput.value = '';
                confirmPasswordInput.value = '';
                
                // 切换到登录标签
                setTimeout(() => {
                    loginTab.click();
                    phoneInput.value = phone; // 填充手机号
                }, 2000);
            }
            
        } catch (error) {
            auth.showError(error.message);
        } finally {
            auth.hideLoading(mainBtn);
        }
    });
    
    // 重置密码
    resetPasswordBtn.addEventListener('click', async () => {
        const phone = document.getElementById('forgotPhone').value.trim();
        const code = document.getElementById('forgotCode').value.trim();
        const newPassword = document.getElementById('newPassword').value;
        const confirmNewPassword = document.getElementById('confirmNewPassword').value;
        
        try {
            if (newPassword !== confirmNewPassword) {
                throw new Error('两次输入的密码不一致');
            }
            
            auth.showLoading(resetPasswordBtn);
            await auth.resetPassword(phone, code, newPassword);
            auth.showSuccess('密码重置成功！');
            
            resetSuccessMessage.style.display = 'block';
            
            setTimeout(() => {
                document.getElementById('backFromForgot').click();
                phoneInput.value = phone;
            }, 2000);
            
        } catch (error) {
            auth.showError(error.message);
        } finally {
            auth.hideLoading(resetPasswordBtn);
        }
    });
    
    // 显示忘记密码表单
    document.getElementById('showForgotPassword').addEventListener('click', () => {
        document.querySelector('.login-form').style.display = 'none';
        document.getElementById('emailForm').style.display = 'none';
        document.getElementById('forgotPasswordForm').style.display = 'block';
    });
    
    // 返回登录按钮
    document.getElementById('backFromForgot').addEventListener('click', () => {
        document.getElementById('forgotPasswordForm').style.display = 'none';
        document.querySelector('.login-form').style.display = 'block';
        loginTab.click();
    });
    
    // 显示邮箱注册表单
    document.getElementById('showEmailRegister').addEventListener('click', () => {
        document.querySelector('.login-form').style.display = 'none';
        document.getElementById('forgotPasswordForm').style.display = 'none';
        document.getElementById('emailForm').style.display = 'block';
    });
    
    // 返回登录
    document.getElementById('backFromEmail').addEventListener('click', () => {
        document.getElementById('emailForm').style.display = 'none';
        document.querySelector('.login-form').style.display = 'block';
        loginTab.click();
    });
    
    // 邮箱注册（保留原有逻辑，暂不集成API）
    document.getElementById('emailRegisterBtn').addEventListener('click', () => {
        alert('邮箱注册功能暂未开放，请使用手机号注册');
    });
    
    // 微信登录（保留原有逻辑，暂不集成API）
    document.getElementById('wechatBtn').addEventListener('click', () => {
        alert('微信登录功能暂未开放，请使用手机号登录');
    });
    
    // 自动聚焦手机号输入框
    if (phoneInput) {
        phoneInput.focus();
    }
});
