// 跨界驿站 - Session Manager
// 会话状态管理，支持页面导航和历史记录
// 统一的localStorage键名：kuajieUserData

(function() {
    'use strict';

    const STORAGE_KEY = 'kuajieUserData';

    // Session State Manager
    window.SessionManager = {
        // 检查用户是否已登录（严格验证）
        isLoggedIn: function() {
            const userData = this.getUserData();
            if (!userData) return false;
            
            // 必须有以下字段才算真正登录
            const hasRequiredFields = userData.userId && userData.phone && userData.loginTime;
            const isMarkedLoggedIn = userData.isLoggedIn === true;
            
            // 检查登录时间是否在24小时内（可选）
            if (hasRequiredFields && userData.loginTime) {
                const loginTime = new Date(userData.loginTime);
                const now = new Date();
                const hoursSinceLogin = (now - loginTime) / (1000 * 60 * 60);
                
                // 超过24小时自动登出
                if (hoursSinceLogin > 24) {
                    this.logout();
                    return false;
                }
            }
            
            return hasRequiredFields && isMarkedLoggedIn;
        },

        // 获取当前用户数据
        getUserData: function() {
            const data = localStorage.getItem(STORAGE_KEY);
            return data ? JSON.parse(data) : null;
        },

        // 保存用户数据
        saveUserData: function(data) {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
        },

        // 用户登出
        logout: function() {
            localStorage.removeItem(STORAGE_KEY);
            this.navigate('/pages/login.html');
        },

        // 带历史记录的页面导航
        navigate: function(url, replaceState = false) {
            // For full page loads, browser history is automatically managed
            // Use replace if we don't want this navigation in history
            if (replaceState) {
                window.location.replace(url);
            } else {
                window.location.href = url;
            }
        },

        // 初始化历史记录支持
        // Note: Browser automatically maintains history for full page navigations
        // Back/forward buttons work natively without custom handlers
        initHistorySupport: function() {
            // No-op: Browser handles history automatically for full page loads
        }
    };

    // Loading Transition Manager
    window.TransitionManager = {
        // 创建加载过渡层
        createOverlay: function() {
            if (document.getElementById('page-transition-overlay')) return;

            const overlay = document.createElement('div');
            overlay.id = 'page-transition-overlay';
            overlay.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: linear-gradient(135deg, #f9f3e9 0%, #f5e8c8 100%);
                z-index: 9999;
                display: flex;
                align-items: center;
                justify-content: center;
                opacity: 0;
                pointer-events: none;
                transition: opacity 0.3s ease;
            `;

            const spinner = document.createElement('div');
            spinner.innerHTML = `
                <div style="
                    width: 50px;
                    height: 50px;
                    border: 3px solid #d4b96a;
                    border-top-color: transparent;
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                "></div>
                <style>
                    @keyframes spin {
                        to { transform: rotate(360deg); }
                    }
                </style>
            `;

            overlay.appendChild(spinner);
            document.body.appendChild(overlay);
        },

        // 显示过渡效果
        show: function() {
            this.createOverlay();
            const overlay = document.getElementById('page-transition-overlay');
            overlay.style.pointerEvents = 'all';
            overlay.style.opacity = '1';
        },

        // 隐藏过渡效果
        hide: function() {
            const overlay = document.getElementById('page-transition-overlay');
            if (overlay) {
                overlay.style.opacity = '0';
                setTimeout(() => {
                    overlay.style.pointerEvents = 'none';
                }, 300);
            }
        },

        // 带过渡效果的页面导航
        navigateWithTransition: function(url, replaceState = false) {
            this.show();
            setTimeout(() => {
                SessionManager.navigate(url, replaceState);
            }, 300);
        }
    };

    // Touch Gesture Manager for Mobile
    window.GestureManager = {
        touchStartX: 0,
        touchEndX: 0,
        minSwipeDistance: 50,

        // 初始化触摸手势
        init: function() {
            document.addEventListener('touchstart', (e) => {
                this.touchStartX = e.changedTouches[0].screenX;
            }, { passive: true });

            document.addEventListener('touchend', (e) => {
                this.touchEndX = e.changedTouches[0].screenX;
                this.handleSwipe();
            }, { passive: true });
        },

        // 处理滑动手势
        handleSwipe: function() {
            const swipeDistance = this.touchEndX - this.touchStartX;
            
            // 向右滑动（返回上一页）
            if (swipeDistance > this.minSwipeDistance) {
                const canGoBack = window.history.length > 1;
                if (canGoBack) {
                    window.history.back();
                }
            }
        },

        // 启用特定页面间的滑动导航
        enablePageSwipe: function(leftPage, rightPage) {
            document.addEventListener('touchend', (e) => {
                const swipeDistance = this.touchEndX - this.touchStartX;
                
                // 向左滑动
                if (swipeDistance < -this.minSwipeDistance && rightPage) {
                    TransitionManager.navigateWithTransition(rightPage);
                }
                // 向右滑动
                else if (swipeDistance > this.minSwipeDistance && leftPage) {
                    TransitionManager.navigateWithTransition(leftPage);
                }
            });
        }
    };

    // 页面加载完成后初始化
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            SessionManager.initHistorySupport();
            GestureManager.init();
            TransitionManager.hide();
        });
    } else {
        SessionManager.initHistorySupport();
        GestureManager.init();
        TransitionManager.hide();
    }
})();
