import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  phone: varchar("phone", { length: 11 }).notNull().unique(),
  passwordHash: text("password_hash"),
  username: text("username"),
  avatar: text("avatar"),
  realName: text("real_name"),
  bio: text("bio"),
  trustedDevices: jsonb("trusted_devices").$type<string[]>().default(sql`'[]'::jsonb`),
  lastLogin: timestamp("last_login"),
  registrationDate: timestamp("registration_date").defaultNow().notNull(),
  points: integer("points").default(0).notNull(),
  isVIP: text("is_vip").default('false'),
  vipExpiry: timestamp("vip_expiry"),
});

export const otpCodes = pgTable("otp_codes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  phone: varchar("phone", { length: 11 }).notNull(),
  code: varchar("code", { length: 6 }).notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  attempts: integer("attempts").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const userSettings = pgTable("user_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  messageNotify: text("message_notify").default('true'),
  checkinNotify: text("checkin_notify").default('true'),
  activityNotify: text("activity_notify").default('false'),
  darkMode: text("dark_mode").default('false'),
  themeColor: text("theme_color").default('default'),
  fontSize: text("font_size").default('medium'),
  language: text("language").default('zh-CN'),
  privacyLevel: text("privacy_level").default('friends'),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const feedback = pgTable("feedback", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  type: text("type").notNull(),
  content: text("content").notNull(),
  contactInfo: text("contact_info"),
  status: text("status").default('pending'),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  trustedDevices: true,
  lastLogin: true,
  registrationDate: true,
  points: true,
  isVIP: true,
  vipExpiry: true,
});

export const insertOtpSchema = createInsertSchema(otpCodes).omit({
  id: true,
  attempts: true,
  createdAt: true,
});

export const insertUserSettingsSchema = createInsertSchema(userSettings).omit({
  id: true,
  updatedAt: true,
});

export const insertFeedbackSchema = createInsertSchema(feedback).omit({
  id: true,
  status: true,
  createdAt: true,
});

// Profile update schema (subset of user fields)
export const updateProfileSchema = z.object({
  username: z.string().min(2).max(20).optional(),
  avatar: z.string().optional(),
  realName: z.string().optional(),
  bio: z.string().max(200).optional(),
});

// Password change schema
export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1),
  newPassword: z.string().min(8).regex(/^(?=.*[A-Za-z])(?=.*\d)/, "密码必须包含字母和数字"),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertOtp = z.infer<typeof insertOtpSchema>;
export type OtpCode = typeof otpCodes.$inferSelect;
export type InsertUserSettings = z.infer<typeof insertUserSettingsSchema>;
export type UserSettings = typeof userSettings.$inferSelect;
export type InsertFeedback = z.infer<typeof insertFeedbackSchema>;
export type Feedback = typeof feedback.$inferSelect;
export type UpdateProfile = z.infer<typeof updateProfileSchema>;
export type ChangePassword = z.infer<typeof changePasswordSchema>;
