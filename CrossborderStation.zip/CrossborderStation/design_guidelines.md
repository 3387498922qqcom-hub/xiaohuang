# Design Guidelines: 跨界驿站 Mobile Web App

## Design Approach: Preserve Existing Design

**Critical Constraint:** All design decisions have already been implemented in the provided HTML files. **NO modifications** to HTML, CSS, JS, text, images, styles, or colors are permitted. These guidelines document the existing design system for integration purposes only.

## Existing Design System

### Color Palette (Already Implemented)
- Background gradients: `#f9f3e9` to `#f5e8c8`
- Primary gold: `#d4b96a`, `#b89b5c`, `#e6d3a3`
- Text: `#8b7355`
- Accents: Various gradients already defined in stylesheets

### Typography (Already Implemented)
- Font family: "PingFang SC", "Helvetica Neue", Arial, sans-serif
- Sizes range from 10px to 28px as defined in existing styles
- Letter spacing and weights already configured

### Layout System (Already Implemented)
- Max container width: 414px (mobile-optimized)
- Padding units: 5px, 8px, 10px, 15px, 20px
- Border radius: 10px, 12px, 15px, 16px, 20px, 25px, 50% (circles)
- All spacing already precisely defined in CSS

### Component Library (Already Implemented)

**Login Page Components:**
- Cloud animation background
- Centered logo with pulse animation
- Tab-based form switcher (login/register)
- Input fields with validation
- WeChat login integration
- Verification code system

**Homepage Components:**
- Fortune card with mood score (0-100 scale)
- 4-bar fortune indicator (love, wealth, career, study)
- 3-column feature grid
- Bottom navigation bar
- VIP badge system
- User points display

**Profile Page Components:**
- Avatar with circular design
- User stats and level display
- Menu items with icons
- Bottom navigation (consistent with homepage)

### Navigation Structure (To Be Integrated)
- Bottom nav items: 首页 (Home), 解读 (Interpret), 道家商城 (Shop), 我的 (Profile)
- Each page maintains independent bottom navigation
- Login page accessible from profile when not authenticated

### Animations (Already Implemented)
- Cloud float animations (30s, 25s, 35s cycles)
- Logo pulse effect (3s cycle)
- Button hover transforms
- Bar chart fill transitions (1s)
- Float button animation (5s cycle)

## Integration Requirements

1. **File Structure:**
   - `/index.html` → Entry point loading 跨界驿站1.0.html
   - `/pages/login.html` → 登录页.html (unchanged)
   - `/pages/profile.html` → 我的页面.html (unchanged)
   - `/pages/home.html` → 跨界驿站1.0.html (unchanged)

2. **Routing Logic:**
   - Implement JavaScript navigation only
   - Connect bottom nav clicks to page transitions
   - Preserve all localStorage functionality
   - Maintain all existing event handlers

3. **Asset Paths:**
   - All CDN links remain unchanged (Font Awesome 6.4.0)
   - No local assets to manage
   - All styles are inline in existing files

## Design Principles Applied (Already in Code)
- Daoist aesthetic with cloud motifs
- Soft, warm color palette
- Generous whitespace and padding
- Subtle shadows and backdrop blur effects
- Responsive touch targets (minimum 40px)
- Glass morphism effects throughout

**Final Note:** This is a code integration project, not a design project. All visual design is complete and must be preserved exactly as provided.