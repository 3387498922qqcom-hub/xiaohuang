// 邀请页面管理
let invitePageInitialized = false;

// 模拟用户数据
const inviteUserData = {
    userId: 10001,
    username: '玄学大师',
    points: 800,
    totalEarnings: 256.40,
    todayEarnings: 12.50,
    withdrawable: 128.20,
    invitedCount: 8,
    inviteCode: '10001',
    records: [
        { 
            type: 'invite', 
            amount: 100, 
            description: '邀请用户注册', 
            time: '今天 10:30', 
            userName: '小明', 
            userNickname: '小明',
            userAvatar: 'https://randomuser.me/api/portraits/men/1.jpg',
            consumptionAmount: null 
        },
        { 
            type: 'commission', 
            amount: 12.50, 
            description: '消费返佣', 
            time: '今天 09:15', 
            userName: '小红', 
            userNickname: '小红',
            userAvatar: 'https://randomuser.me/api/portraits/women/2.jpg',
            consumptionAmount: 62.50 
        },
        { 
            type: 'invite', 
            amount: 100, 
            description: '邀请用户注册', 
            time: '昨天 16:20', 
            userName: '小刚', 
            userNickname: '小刚',
            userAvatar: 'https://randomuser.me/api/portraits/men/3.jpg',
            consumptionAmount: null 
        },
        { 
            type: 'commission', 
            amount: 8.90, 
            description: '消费返佣', 
            time: '昨天 14:45', 
            userName: '小美', 
            userNickname: '小美',
            userAvatar: 'https://randomuser.me/api/portraits/women/4.jpg',
            consumptionAmount: 89.00 
        },
        { 
            type: 'commission', 
            amount: 15.60, 
            description: '消费返佣', 
            time: '前天 11:10', 
            userName: '小李', 
            userNickname: '小李',
            userAvatar: 'https://randomuser.me/api/portraits/men/5.jpg',
            consumptionAmount: 78.00 
        }
    ]
};

// 初始化邀请页面（只初始化一次）
function initInvitePage() {
    if (invitePageInitialized) {
        // 已初始化，只更新数据（不使用动画）
        updateInviteUserDisplay(false);
        return Promise.resolve();
    }
    
    // 加载HTML内容
    return fetch('/pages/invite-content.html')
        .then(response => response.text())
        .then(html => {
            // 插入HTML
            const container = document.getElementById('invitePageContainer');
            if (container) {
                container.innerHTML = html;
            }
            
            // 加载CSS
            if (!document.getElementById('invite-css')) {
                const link = document.createElement('link');
                link.id = 'invite-css';
                link.rel = 'stylesheet';
                link.href = '/css/invite.css';
                document.head.appendChild(link);
            }
            
            // 更新用户显示（首次显示使用动画）
            updateInviteUserDisplay(true);
            
            // 渲染收益记录
            renderInviteRecords();
            
            // 绑定事件
            bindInviteEvents();
            
            // 标记为已初始化
            invitePageInitialized = true;
        })
        .catch(error => {
            console.error('Error loading invite page:', error);
        });
}

// 数字滚动动画函数
function countUpAnimation(element, start, end, duration, decimals = 0) {
    if (!element) return;
    
    const startTime = performance.now();
    const range = end - start;
    
    // 使用 easeOutCubic 缓动函数，让动画更自然
    function easeOutCubic(t) {
        return 1 - Math.pow(1 - t, 3);
    }
    
    function updateNumber(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const easedProgress = easeOutCubic(progress);
        const current = start + (range * easedProgress);
        
        element.textContent = current.toFixed(decimals);
        
        if (progress < 1) {
            requestAnimationFrame(updateNumber);
        } else {
            // 确保最终显示准确的数值
            element.textContent = end.toFixed(decimals);
        }
    }
    
    requestAnimationFrame(updateNumber);
}

// 更新用户显示（带滚动动画）
function updateInviteUserDisplay(animate = true) {
    const totalEarningsEl = document.getElementById('inviteTotalEarnings');
    const todayEarningsEl = document.getElementById('inviteTodayEarnings');
    const withdrawableEl = document.getElementById('inviteWithdrawable');
    const invitedCountEl = document.getElementById('inviteInvitedCount');
    const inviteCodeEl = document.getElementById('inviteCodeDisplay');
    
    if (animate) {
        // 使用动画效果
        if (totalEarningsEl) {
            countUpAnimation(totalEarningsEl, 0, inviteUserData.totalEarnings, 1500, 2);
        }
        if (todayEarningsEl) {
            countUpAnimation(todayEarningsEl, 0, inviteUserData.todayEarnings, 1200, 2);
        }
        if (withdrawableEl) {
            countUpAnimation(withdrawableEl, 0, inviteUserData.withdrawable, 1300, 2);
        }
        if (invitedCountEl) {
            countUpAnimation(invitedCountEl, 0, inviteUserData.invitedCount, 1000, 0);
        }
    } else {
        // 直接显示，不使用动画
        if (totalEarningsEl) totalEarningsEl.textContent = inviteUserData.totalEarnings.toFixed(2);
        if (todayEarningsEl) todayEarningsEl.textContent = inviteUserData.todayEarnings.toFixed(2);
        if (withdrawableEl) withdrawableEl.textContent = inviteUserData.withdrawable.toFixed(2);
        if (invitedCountEl) invitedCountEl.textContent = inviteUserData.invitedCount;
    }
    
    // 邀请码始终直接显示，不需要动画
    if (inviteCodeEl) inviteCodeEl.textContent = inviteUserData.inviteCode;
}

// 渲染收益记录（首页）
function renderInviteRecords() {
    const recordsList = document.getElementById('inviteRecordsList');
    if (!recordsList) return;
    
    recordsList.innerHTML = '';
    
    // 只显示最近的5条记录
    const recentRecords = inviteUserData.records.slice(0, 5);
    
    recentRecords.forEach(record => {
        const recordItem = document.createElement('div');
        recordItem.className = 'record-item';
        
        const amount = record.type === 'invite' ? 
            `+${record.amount}积分` : 
            `+¥${record.amount.toFixed(2)}`;
        
        // 消费信息显示
        let consumptionInfo = '';
        if (record.type === 'commission' && record.consumptionAmount) {
            consumptionInfo = `<span class="record-consumption">消费¥${record.consumptionAmount.toFixed(2)}</span>`;
        }
        
        recordItem.innerHTML = `
            <div class="record-info">
                <img class="record-avatar" src="${record.userAvatar}" alt="${record.userNickname}">
                <div class="record-details">
                    <div class="record-title">${record.type === 'invite' ? '邀请奖励' : '消费返佣'}</div>
                    <div class="record-desc">
                        <span class="record-user">${record.userNickname}</span>
                        ${consumptionInfo}
                        <span class="record-time">${record.time}</span>
                    </div>
                </div>
            </div>
            <div class="record-amount">${amount}</div>
        `;
        
        recordsList.appendChild(recordItem);
    });
}

// 渲染全部收益记录
function renderInviteFullRecords() {
    const fullRecordsList = document.getElementById('inviteFullRecordsList');
    if (!fullRecordsList) return;
    
    fullRecordsList.innerHTML = '';
    
    inviteUserData.records.forEach(record => {
        const recordItem = document.createElement('div');
        recordItem.className = 'full-record-item';
        
        const amount = record.type === 'invite' ? 
            `+${record.amount}积分` : 
            `+¥${record.amount.toFixed(2)}`;
        
        let consumptionInfo = '';
        if (record.type === 'commission' && record.consumptionAmount) {
            consumptionInfo = `<div class="full-record-consumption">消费金额: ¥${record.consumptionAmount.toFixed(2)}</div>`;
        }
        
        recordItem.innerHTML = `
            <div class="full-record-info">
                <img class="full-record-avatar" src="${record.userAvatar}" alt="${record.userNickname}">
                <div class="full-record-details">
                    <div class="full-record-title">${record.type === 'invite' ? '邀请奖励' : '消费返佣'}</div>
                    <div class="full-record-user">${record.userNickname}</div>
                    <div class="full-record-time">${record.time}</div>
                    ${consumptionInfo}
                </div>
            </div>
            <div class="full-record-amount">${amount}</div>
        `;
        
        fullRecordsList.appendChild(recordItem);
    });
}

// 绑定事件
function bindInviteEvents() {
    // 复制邀请码
    const copyInviteBtn = document.getElementById('copyInviteBtn');
    if (copyInviteBtn) {
        copyInviteBtn.addEventListener('click', function() {
            const inviteCode = document.getElementById('inviteCodeDisplay').textContent;
            
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(inviteCode).then(() => {
                    alert('邀请码已复制到剪贴板');
                }).catch(() => {
                    fallbackCopyInvite(inviteCode);
                });
            } else {
                fallbackCopyInvite(inviteCode);
            }
        });
    }
    
    // 分享功能
    const shareWechat = document.getElementById('shareWechat');
    if (shareWechat) {
        shareWechat.addEventListener('click', function() {
            alert('微信分享功能开发中，请先复制邀请码');
        });
    }
    
    const shareQQ = document.getElementById('shareQQ');
    if (shareQQ) {
        shareQQ.addEventListener('click', function() {
            alert('QQ分享功能开发中，请先复制邀请码');
        });
    }
    
    const shareLink = document.getElementById('shareLink');
    if (shareLink) {
        shareLink.addEventListener('click', function() {
            const inviteLink = `https://kuajieyizhan.fun/register?invite=${inviteUserData.inviteCode}`;
            
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(inviteLink).then(() => {
                    alert('邀请链接已复制到剪贴板');
                }).catch(() => {
                    fallbackCopyInvite(inviteLink);
                });
            } else {
                fallbackCopyInvite(inviteLink);
            }
        });
    }
    
    // 任务按钮
    const inviteTaskBtn = document.getElementById('inviteTaskBtn');
    if (inviteTaskBtn) {
        inviteTaskBtn.addEventListener('click', function() {
            alert('去邀请好友页面');
        });
    }
    
    // 查看规则按钮
    const commissionTaskBtn = document.getElementById('inviteCommissionTaskBtn');
    if (commissionTaskBtn) {
        commissionTaskBtn.addEventListener('click', function() {
            const modal = document.getElementById('inviteRulesModal');
            if (modal) modal.classList.add('show');
        });
    }
    
    // 查看全部记录按钮
    const viewAllRecords = document.getElementById('viewAllRecords');
    if (viewAllRecords) {
        viewAllRecords.addEventListener('click', function() {
            renderInviteFullRecords();
            const modal = document.getElementById('inviteAllRecordsModal');
            if (modal) modal.classList.add('show');
        });
    }
    
    // 关闭规则弹窗
    const closeRulesModal = document.getElementById('closeInviteRulesModal');
    if (closeRulesModal) {
        closeRulesModal.addEventListener('click', function() {
            const modal = document.getElementById('inviteRulesModal');
            if (modal) modal.classList.remove('show');
        });
    }
    
    // 关闭全部记录弹窗
    const closeAllRecordsModal = document.getElementById('closeInviteAllRecordsModal');
    if (closeAllRecordsModal) {
        closeAllRecordsModal.addEventListener('click', function() {
            const modal = document.getElementById('inviteAllRecordsModal');
            if (modal) modal.classList.remove('show');
        });
    }
    
    // 点击弹窗外部关闭
    const rulesModal = document.getElementById('inviteRulesModal');
    if (rulesModal) {
        rulesModal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('show');
            }
        });
    }
    
    const allRecordsModal = document.getElementById('inviteAllRecordsModal');
    if (allRecordsModal) {
        allRecordsModal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('show');
            }
        });
    }
}

// 兼容性复制方法
function fallbackCopyInvite(text) {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    document.body.appendChild(textArea);
    textArea.select();
    
    try {
        document.execCommand('copy');
        alert('已复制到剪贴板');
    } catch (err) {
        alert('复制失败，请手动复制');
    }
    
    document.body.removeChild(textArea);
}
