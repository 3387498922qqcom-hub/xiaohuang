# 跨界驿站 - Daoist Mysticism Mobile Web Application

## Overview

跨界驿站 (Cross-boundary Station) is a mobile-first web application offering Daoist mysticism and fortune-telling services. It features a distinctive Chinese-inspired design with cloud animations, golden color schemes, and traditional aesthetic elements. The application provides daily fortune readings, mystical consultations, VIP membership, and a points-based engagement system. It integrates three core pages (login, home, profile) into a cohesive experience with modern navigation features like session management, browser history support, loading transitions, and touch gesture controls. The business vision is to create an immersive digital platform for traditional Daoist practices, targeting users interested in cultural mysticism and personal guidance, with high potential for engagement through its unique blend of aesthetics and interactive features.

## Recent Updates

### November 12, 2025 - Invite Earnings Visual Optimization & Task Card Layout
- **Enhanced premium UI/UX for invite earnings page** (福袋 - Lucky Bag section):
  - **Glass-morphism effects**: Applied `backdrop-filter: blur(10px)` with semi-transparent gradient backgrounds to all major card sections (earnings overview, task cards, invite section, records section)
  - **Number scrolling animation**: Implemented smooth countUp animation using requestAnimationFrame with easeOutCubic easing curve
    - Earnings numbers animate from 0 to actual values on first page load (1000-1500ms durations)
    - Subsequent visits display values instantly without animation for better UX
  - **Enhanced hover interactions**: 3D card lift effects (`translateY(-4px) scale(1.02)`), icon rotations (360deg), button ripples, and shimmer sweep animations
  - **Gradient optimizations**: Upgraded from 2-color to 3-color gradients for visual depth, added text gradients using background-clip
  - **Animated effects**: Rotating shimmer animation on invite code box, multi-layer box shadows with inset highlights
  - **Performance**: All animations use CSS transforms and requestAnimationFrame for smooth 60fps performance
  - **Task card layout optimization**:
    - Changed to horizontal text layout with "·" separators between segments
    - Implemented intelligent wrapping (`flex-wrap: wrap`) to show complete text without truncation
    - Each text segment maintains integrity (`white-space: nowrap`) while allowing multi-line display
    - Buttons perfectly centered within cards (`align-self: center`, verified <0.01px alignment error)
    - Font sizes optimized (13-14px) for readability on mobile 414px width
  - **Testing**: All features E2E tested and verified - visual effects, animations, text display, and button alignment working correctly

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System:** React 18 with TypeScript, Vite for fast HMR and optimized builds, and Wouter for lightweight client-side routing.

**UI Component System:** `shadcn/ui` (built on Radix UI primitives) in "new-york" style, Tailwind CSS for utility-first styling with custom design tokens, and a mobile-first responsive design constrained to a 414px maximum width. Custom color system uses CSS variables for theme consistency, adhering to a predefined palette (warm gradients, gold accents) and typography (PingFang SC).

**State Management:** TanStack Query (React Query) for server state management and data fetching. React Hook Form with Zod for form validation.

**Navigation System:** Enhanced cross-page navigation including `SessionManager` for consistent session persistence (`localStorage`), native browser history support, `TransitionManager` for smooth loading transitions with a spinner, and `GestureManager` for mobile-optimized swipe-right navigation.

### Backend Architecture

**Server Framework:** Express.js on Node.js (ESM modules) with custom middleware for request logging and JSON body parsing.

**API Design:** RESTful API with an `/api` prefix, serving static files from the `public/` directory. Session-based route structure is prepared.

### Data Storage Solutions

**Database:** PostgreSQL as the primary relational database, utilizing Neon Database for serverless deployment.

**ORM & Schema Management:** Drizzle ORM for type-safe database operations, with schema definitions in `shared/schema.ts` and Zod integration. A migration system outputs to `./migrations`. The current schema includes a `users` table with UUID primary keys, username/password fields, and unique username constraints. `MemStorage` is used for development/testing, providing a swappable interface for database interaction.

### Authentication & Authorization

**Current Implementation:** Basic user storage with username/password fields (passwords currently plain text, pending hashing). User creation and lookup operations are defined.

**Session Management:** `connect-pg-simple` is installed for PostgreSQL-backed sessions, and Express session infrastructure is prepared.

**Security Considerations:** Raw body preservation for webhook signature verification, CORS and credential handling configured, and 401 unauthorized handling implemented.

## External Dependencies

**UI Component Libraries:** Radix UI (comprehensive accessible component primitives), Lucide React (icons), class-variance-authority, cmdk (command palette), embla-carousel-react (carousel), vaul (drawer component).

**Styling & Design:** Tailwind CSS, tailwindcss-animate, clsx, tailwind-merge.

**Form Handling:** React Hook Form, @hookform/resolvers, Zod, drizzle-zod.

**Date & Time:** date-fns.

**Development Tools:** vite-plugin-runtime-error-modal, cartographer, dev-banner (Replit plugins), tsx, esbuild, drizzle-kit.

**API & Data Fetching:** Custom `apiRequest` wrapper for fetch, handling JSON, errors, and cookie-based credentials.

**Font Loading:** Google Fonts integration (Architects Daughter, DM Sans, Fira Code, Geist Mono) with preconnect optimization.