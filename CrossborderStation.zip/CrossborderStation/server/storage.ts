import { type User, type InsertUser, type OtpCode, type InsertOtp, type UserSettings, type InsertUserSettings, type Feedback, type InsertFeedback, type UpdateProfile } from "@shared/schema";
import { randomUUID } from "crypto";
import crypto from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByPhone(phone: string): Promise<User | undefined>;
  createUser(phone: string, passwordHash?: string): Promise<User>;
  updatePassword(phone: string, passwordHash: string): Promise<boolean>;
  updateProfile(userId: string, profile: UpdateProfile): Promise<boolean>;
  updateLastLogin(phone: string): Promise<boolean>;
  addTrustedDevice(phone: string, deviceId: string): Promise<boolean>;
  isTrustedDevice(phone: string, deviceId: string): Promise<boolean>;
  removeTrustedDevice(phone: string, deviceId: string): Promise<boolean>;
  updateUserPoints(phone: string, pointsChange: number): Promise<boolean>;
  
  generateOTP(phone: string): Promise<{ code: string; expiresAt: Date } | null>;
  verifyOTP(phone: string, code: string): Promise<boolean>;
  getOTP(phone: string): Promise<OtpCode | undefined>;
  deleteOTP(phone: string): Promise<boolean>;
  
  getUserSettings(userId: string): Promise<UserSettings | undefined>;
  createUserSettings(userId: string): Promise<UserSettings>;
  updateUserSettings(userId: string, settings: Partial<UserSettings>): Promise<boolean>;
  
  createFeedback(feedback: InsertFeedback): Promise<Feedback>;
  getFeedbackByUser(userId: string): Promise<Feedback[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private otpCodes: Map<string, OtpCode>;
  private otpRequestCount: Map<string, { count: number; resetTime: number }>;
  private userSettings: Map<string, UserSettings>;
  private feedbacks: Map<string, Feedback>;

  constructor() {
    this.users = new Map();
    this.otpCodes = new Map();
    this.otpRequestCount = new Map();
    this.userSettings = new Map();
    this.feedbacks = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByPhone(phone: string): Promise<User | undefined> {
    const user = Array.from(this.users.values()).find(user => user.phone === phone);
    console.log(`[Storage] getUserByPhone(${phone}): ${user ? 'FOUND' : 'NOT FOUND'}, Total users: ${this.users.size}`);
    return user;
  }

  async createUser(phone: string, passwordHash?: string): Promise<User> {
    const id = randomUUID();
    const user: User = {
      id,
      phone,
      passwordHash: passwordHash || null,
      username: null,
      avatar: null,
      realName: null,
      bio: null,
      trustedDevices: null,
      lastLogin: null,
      registrationDate: new Date(),
      points: 50, // 注册奖励
      isVIP: 'false',
      vipExpiry: null,
    };
    this.users.set(id, user);
    console.log(`[Storage] User created: ${phone}, Total users: ${this.users.size}`);
    return user;
  }

  async updatePassword(phone: string, passwordHash: string): Promise<boolean> {
    const user = await this.getUserByPhone(phone);
    if (!user) {
      console.log(`[Storage] updatePassword FAILED: User ${phone} not found`);
      return false;
    }
    user.passwordHash = passwordHash;
    console.log(`[Storage] Password updated for ${phone}`);
    return true;
  }

  async updateLastLogin(phone: string): Promise<boolean> {
    const user = await this.getUserByPhone(phone);
    if (!user) return false;
    user.lastLogin = new Date();
    return true;
  }

  async addTrustedDevice(phone: string, deviceId: string): Promise<boolean> {
    const user = await this.getUserByPhone(phone);
    if (!user) return false;
    
    const devices = user.trustedDevices || [];
    if (!devices.includes(deviceId)) {
      user.trustedDevices = [...devices, deviceId];
    }
    return true;
  }

  async isTrustedDevice(phone: string, deviceId: string): Promise<boolean> {
    const user = await this.getUserByPhone(phone);
    if (!user || !user.trustedDevices) return false;
    return user.trustedDevices.includes(deviceId);
  }

  async removeTrustedDevice(phone: string, deviceId: string): Promise<boolean> {
    const user = await this.getUserByPhone(phone);
    if (!user || !user.trustedDevices) return false;
    
    user.trustedDevices = user.trustedDevices.filter(id => id !== deviceId);
    return true;
  }

  async updateUserPoints(phone: string, pointsChange: number): Promise<boolean> {
    const user = await this.getUserByPhone(phone);
    if (!user) return false;
    user.points = Math.max(0, user.points + pointsChange);
    return true;
  }

  async generateOTP(phone: string): Promise<{ code: string; expiresAt: Date } | null> {
    const now = Date.now();
    const oneHour = 60 * 60 * 1000;
    
    let rateLimit = this.otpRequestCount.get(phone);
    if (rateLimit && now < rateLimit.resetTime) {
      if (rateLimit.count >= 3) {
        return null;
      }
      rateLimit.count++;
    } else {
      this.otpRequestCount.set(phone, {
        count: 1,
        resetTime: now + oneHour,
      });
    }
    
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(now + 5 * 60 * 1000);
    
    const otpCode: OtpCode = {
      id: randomUUID(),
      phone,
      code,
      expiresAt,
      attempts: 0,
      createdAt: new Date(),
    };
    
    this.otpCodes.set(phone, otpCode);
    
    console.log(`[SMS] 验证码已发送到 ${phone}: ${code} (有效期5分钟)`);
    
    return { code, expiresAt };
  }

  async verifyOTP(phone: string, code: string): Promise<boolean> {
    const otpCode = this.otpCodes.get(phone);
    if (!otpCode) return false;
    
    if (otpCode.attempts >= 3) {
      this.otpCodes.delete(phone);
      return false;
    }
    
    if (new Date() > otpCode.expiresAt) {
      this.otpCodes.delete(phone);
      return false;
    }
    
    otpCode.attempts++;
    
    if (otpCode.code === code) {
      this.otpCodes.delete(phone);
      return true;
    }
    
    return false;
  }

  async getOTP(phone: string): Promise<OtpCode | undefined> {
    return this.otpCodes.get(phone);
  }

  async deleteOTP(phone: string): Promise<boolean> {
    return this.otpCodes.delete(phone);
  }

  async updateProfile(userId: string, profile: UpdateProfile): Promise<boolean> {
    const user = await this.getUser(userId);
    if (!user) {
      console.log(`[Storage] updateProfile FAILED: User ${userId} not found`);
      return false;
    }
    
    if (profile.username !== undefined) user.username = profile.username;
    if (profile.avatar !== undefined) user.avatar = profile.avatar;
    if (profile.realName !== undefined) user.realName = profile.realName;
    if (profile.bio !== undefined) user.bio = profile.bio;
    
    console.log(`[Storage] Profile updated for user ${userId}`);
    return true;
  }

  async getUserSettings(userId: string): Promise<UserSettings | undefined> {
    const existingSettings = Array.from(this.userSettings.values()).find(s => s.userId === userId);
    if (existingSettings) {
      return existingSettings;
    }
    
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const newSettings = await this.createUserSettings(userId);
    return newSettings;
  }

  async createUserSettings(userId: string): Promise<UserSettings> {
    const id = randomUUID();
    const settings: UserSettings = {
      id,
      userId,
      messageNotify: 'true',
      checkinNotify: 'true',
      activityNotify: 'false',
      darkMode: 'false',
      themeColor: 'default',
      fontSize: 'medium',
      language: 'zh-CN',
      privacyLevel: 'friends',
      updatedAt: new Date(),
    };
    this.userSettings.set(id, settings);
    console.log(`[Storage] User settings created for user ${userId}`);
    return settings;
  }

  async updateUserSettings(userId: string, settings: Partial<UserSettings>): Promise<boolean> {
    let userSettings = await this.getUserSettings(userId);
    if (!userSettings) {
      userSettings = await this.createUserSettings(userId);
    }
    
    Object.assign(userSettings, settings, { updatedAt: new Date() });
    console.log(`[Storage] User settings updated for user ${userId}`);
    return true;
  }

  async createFeedback(feedback: InsertFeedback): Promise<Feedback> {
    const id = randomUUID();
    const newFeedback: Feedback = {
      id,
      userId: feedback.userId,
      type: feedback.type,
      content: feedback.content,
      contactInfo: feedback.contactInfo || null,
      status: 'pending',
      createdAt: new Date(),
    };
    this.feedbacks.set(id, newFeedback);
    console.log(`[Storage] Feedback created for user ${feedback.userId}`);
    return newFeedback;
  }

  async getFeedbackByUser(userId: string): Promise<Feedback[]> {
    return Array.from(this.feedbacks.values()).filter(f => f.userId === userId);
  }
}

export const storage = new MemStorage();
